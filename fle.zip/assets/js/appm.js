/*
	app js for fledigital.com
	version 1.0
*/

//$('.navbar').css({"height":"7rem"});