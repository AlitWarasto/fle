		<footer>
			<div class="container bRedOld">
				<div class="row p-3 flex-column align-items-center">
					<h6 class="cWhite">Powered By <a href="http://pramudiringga.com"><span class="cWhite">pramudiringga.com</span></a></h6>
					<h6 class="cWhite">copyright &copy; <span class="cWhite">2021</span><span> jagokeuangan.com</span></h6>
				</div>
			</div>
		</footer>
		<a class="btnWA" href="https://api.whatsapp.com/send?phone=628112633997&text=Halo%20admin%2C%20bisa%20bantu%20saya%3F"><button class="btn btn-success" style="background-color: #61ce70;"><span class="h4"><i class="fab fa-whatsapp"> </i> </span>Butuh Bantuan?</button></a>
		<?php wp_footer(); ?>

	</body>
</html>